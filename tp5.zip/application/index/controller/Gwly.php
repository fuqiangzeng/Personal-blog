<?php
namespace app\index\controller;
use think\Db;
use think\Config;
class Gwly extends Common
{
    public function index()
    {
        $config = Db::table('think_lmsg')->select();;
        $this->assign('config',$config);
        return $this->fetch();
    }
}