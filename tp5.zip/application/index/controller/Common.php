<?php
namespace app\index\controller;

/**
 *
 */
use think\Controller;
use think\Session;
use think\Db;
class Common extends Controller
{
	//继承session
	function _initialize ()
	{
		$name = Session::get('name');
		$this->assign('name',$name);
	}
	//处理留言
	public function lmsg(){
		$user = Session::get('name');
		$main = htmlspecialchars(input('main'));
		if(!$name = Session::get('name')){
			$this->error('您还没有登录，请先登录!');
		}else if(!$main){
			$this->error('您还没有填写留言内容!');
		}else{
			//写入数据到数据库中
			$data = [
				'username' => $user,
				'main' => $main,
				'time' => time('Y-m-d')
			];
			//返回1就写入成功 0 就失败
			$log = Db::name('lmsg')->insert($data);
			if($log == 1){
				//写入成功 跳转到登录页面
				$this->success('留言成功', 'Gwly/index');
			}else{
				$this->error("留言成功");
			}
		}
	}

}




?>