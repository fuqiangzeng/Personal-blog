<?php
namespace app\index\controller;
use think\Request;
use think\Db;
use think\Session;
class Listt extends Common
{
    public function index()
    {
    	$config = Db::table('think_article')->select();;
        $this->assign('config',$config);
       return $this->fetch();
    }
    //处理点击 页面里面的内容 通过url传值过来 
    public function listview()
    {
    	//获取url
    	$request = Request::instance();
    	//拿到路径
    	$lead = $request->param();
    	//取到页面带过来的id
    	$lead_id = $lead['id'];

    	//查询数据
    	$config = Db::table('think_article')->where('id',$lead_id)->find();
        $this->assign('config',$config);

        $reviews = Db::table('think_article_reviews')->select();
        $this->assign('reviews',$reviews);
        return $this->fetch();
    }
   	 //处理文章评论
    public function reviews(){
    	  //获取url
    	$request = Request::instance();
    	//拿到路径
    	$lead = $request->param();
    	//取到页面带过来的id
    	$lead_id = $lead['id'];
    	var_dump($lead_id);
		$user = Session::get('name');
		$main = input('main');
		if(!$name = Session::get('name')){
			$this->error('您还没有登录，请先登录!');
		}else if(!$main){
			$this->error('您还没有填写留言内容!');
		}else{
			//写入数据到数据库中
			$data = [
				'username' => $user,
				'main' => $main,
				'time' => time('Y-m-d')
			];
			//返回1就写入成功 0 就失败
			$log = Db::name('article_reviews')->insert($data);
			if($log == 1){
				//写入成功
				$this->success('留言成功',url('Listt/listview',['id'=>$lead_id]));
			}else{
				$this->error("留言成功");
			}
		}
	}

}
