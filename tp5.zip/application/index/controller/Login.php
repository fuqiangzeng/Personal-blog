<?php
namespace app\index\controller;


use think\Controller;
use think\Db;
use think\Session;
use think\Cache;
class Login extends Controller
{
	//登录页面
	public function index(){
		  return $this->fetch();
	}
	//注册页面
	public function registered(){
		return $this->fetch();
	}
	//处理注册提交过来的数据
	public function filter(){
		//获取提交过来的数据
		$name = input('name');
		$user = input('user');
		$password = input('password');
		$captcha = input('code');
		//查询昵称是否注册
		$tquer = Db::table('think_user')->where('username',$name)->select();
		//查询手机号是否注册
		$tmobile = Db::table('think_user')->where('mobile',$user)->select();
		//判断是否已注册、判断密码是否一致、判断验证码
		if($tquer){
			$this->error('用户名已注册，请重新注册');
		}else if($tmobile){
			$this->error("手机已注册，请重新注册");
		}else if(!captcha_check($captcha)){
			$this->error("验证码错误，请重输");
		}else{
			//写入数据到数据库中
			$data = [
				'username' => $name,
				'mobile' => $user,
				'password' => md5($password)
			];
			//返回1就写入成功 0 就失败
			$log = Db::name('user')->insert($data);
			if($log == 1){
				//写入成功 跳转到登录页面
				$this->success('注册成功', 'Login/index');
			}else{
				$this->error("注册失败");
			}
		}
	}
	//登录验证
	public function logintion(){
		//获取提交过来的数据
		$user = input('user');
		$password = input('password');
		$captcha = input('code');
		//查询昵称是否有这个账号
		$tquer = Db::table('think_user')->where('mobile',$user)->find();
		//判断账号、密码、验证码
		if($user !== $tquer['mobile']){
			$this->error('账号不对或没注册');
		}else if(md5($password) !== $tquer['password']){
			$this->error('密码不对');
		}else if(!captcha_check($captcha)){
			$this->error("验证码错误，请重输");
		}else{
			//验证登录成功  把昵称用session方式保存出去
			Session::set('name',$tquer['username']);
			//跳转页面
			$this->success('登录成功', 'index/index');
		}
	}
	public function exitindec(){
		// 删除（当前作用域）
		Session::delete('name');
		$this->success('退出登录成功','index/index/index');
	}
}

?>