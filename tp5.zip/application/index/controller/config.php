<?php
return [
	'default_filter'         => 'htmlspecialchars',

]




?>