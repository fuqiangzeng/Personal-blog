<?php
namespace app\index\controller;

class Listshow extends Common
{
    public function index()
    {
       return $this->fetch();
    }
}
