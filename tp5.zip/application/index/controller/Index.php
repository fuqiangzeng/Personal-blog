<?php
namespace app\index\controller;

use think\Db;
class Index extends Common
{
    public function index()
    {
        $config = Db::table('think_article')->select();;
        $this->assign('config',$config);
        $house = Db::table('think_house')->select();;
        $this->assign('house',$house);
       	return $this->fetch();
    }
}
