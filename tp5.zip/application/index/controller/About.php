<?php
namespace app\index\controller;

class About extends Common
{
    public function index()
    {
        return $this->fetch();
    }
}