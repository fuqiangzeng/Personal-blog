<?php
namespace app\index\controller;

use think\Request;
use think\Db;

class Xqsw extends Common
{
    public function index()
    {
    	$house = Db::table('think_house')->select();;
        $this->assign('house',$house);
        return $this->fetch();
    }
    public function listview(){
    	    	//获取url
    	$request = Request::instance();
    	//拿到路径
    	$lead = $request->param();
    	//取到页面带过来的id
    	$lead_id = $lead['id'];
    	//查询数据
    	$config = Db::table('think_house')->where('id',$lead_id)->find();
        $this->assign('config',$config);
    	return $this->fetch();
    }
}