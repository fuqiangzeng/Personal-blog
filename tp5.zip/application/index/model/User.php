<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/3/24
 * Time: 11:44
 */

namespace app\index\model;


use think\Model;

class User extends Model
{
    protected $name='lmsg';
}