<?php
namespace app\admin\controller;

use think\Controller;
use think\Db;

/**
 * 
 */
class Adminindex extends Controller
{
	public function index(){
		return $this->fetch();
	}
	//点击退出按钮，清除缓存
	public function exitindec(){
		$this->success('退出登录成功','index/index/index');
	}
}








?>