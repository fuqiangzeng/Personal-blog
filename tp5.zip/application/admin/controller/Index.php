<?php
namespace app\admin\controller;

use think\Controller;
use think\Db;
class Index extends Controller
{
	//后台登录页面
    public function index()
    {
        return $this->fetch();
    }
    //处理登录
    public function logoin(){
    	$user = input('user');
    	$pass = input('password');
    	if(!($user == '13232619367')){
    		$this->error('账号不对');
    	}else if(!($pass == 'zxc12345')){
    		$this->error('密码不正确');
    	}else{
    		$this->success('登录成功','adminindex/index');
    	}
    }
}
