<?php
namespace app\admin\controller;

use think\Controller;
use think\Db;
use think\Request;
/**
 *
 */
class House extends Controller
{
	//查询数据
	public function index(){
		$config = Db::table('think_house')->select();;
        $this->assign('config',$config);
		return $this->fetch();
	}
	//处理删除的数据
	public function delarticle(){
		//获取url
    	$request = Request::instance();
    	//拿到路径
    	$lead = $request->param();
    	//取到页面带过来的id
    	$lead_id = $lead['id'];
    	//删除数据
    	$config = Db::table('think_house')->where('id',$lead_id)->delete();
    	if($config == 1){
    		$this->success('删除书籍成功','house/index');
    	}else{
    		$this->error('删除书籍失败');
    	}
	}
	//添加书籍
	public function addindex(){
		return $this->fetch();
	}
	//处理数据
	public function getindex(){
		 // 获取表单上传文件 例如上传了001.jpg
	    $file = request()->file('photo');
	    // 移动到框架应用根目录/public/uploads/ 目录下
	    if($file){
	        $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
	        if($info){
	            // 成功上传后 获取上传信息
	            // 输出 jpg
	            // echo $info->getExtension();
	            // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
	            $photo = $info->getSaveName();
	            // 输出 42a79759f284b767dfcb2a0197904287.jpg
	            // echo $info->getFilename();
	        }else{
	            // 上传失败获取错误信息
	            echo $file->getError();
	        }
		}else{
			echo "上传失败";
		}
		$title = input('title');
		$remark = input('remark');
		$views = input('views');
		$content = input('content');
		//写入数据到数据库中
		$data = [
			'title' => $title,
			'photo' => $photo,
			'remark' => $remark,
			'content' => $content,
			'views' => $views,
			'create_time' => time()
		];
		// dump($data);
		//返回1就写入成功 0 就失败
		$log = Db::name('house')->insert($data);
		if($log == 1){
			//写入成功 跳转到返回写入页面
			$this->success('添加书籍成功', 'house/addindex');
		}else{
			$this->error("添加书籍失败");
		}
	}
	//修改书籍页面
	public function edithouse(){
		//获取url
    	$request = Request::instance();
    	//拿到路径
    	$lead = $request->param();
    	//取到页面带过来的id
    	$lead_id = $lead['id'];
    	//返回数据数据
    	$config = Db::table('think_house')->where('id',$lead_id)->find();
    	$this->assign('config',$config);
		return $this->fetch();
	}
	//处理修改后的数据  再写入数据库
	public function addedithouse(){
		//获取url
    	$request = Request::instance();
    	//拿到路径
    	$lead = $request->param();
    	//取到页面带过来的id
    	$lead_id = $lead['id'];
    	// 获取表单上传文件 例如上传了001.jpg
	    $file = request()->file('photo');
	    // 移动到框架应用根目录/public/uploads/ 目录下
	    if($file){
	        $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
	        if($info){
	            // 成功上传后 获取上传信息
	            // 输出 jpg
	            // echo $info->getExtension();
	            // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
	            $photo = $info->getSaveName();
	            // 输出 42a79759f284b767dfcb2a0197904287.jpg
	            // echo $info->getFilename();
	        }else{
	            // 上传失败获取错误信息
	            echo $file->getError();
	        }
		}else{
			$photo = null;
		}
		$title = input('title');
		$remark = input('remark');
		$views = input('views');
		$content = input('content');
		$label = input('label');
		//写入数据到数据库中
		$data = [
			'id' => $lead_id,
			'title' => $title,
			'photo' => $photo,
			'remark' => $remark,
			'content' => $content,
			'views' => $views,
			'create_time' => time()
		];
		$log = Db::table('think_house')->where('id', $lead_id)->update($data);
		if($log == 1){
			//写入成功 跳转到返回写入页面
			$this->success('修改成功', 'house/index');
		}else{
			$this->error("修改成功");
		}
	}
}

?>