<?php 
namespace app\admin\controller;

use think\Controller;
use think\Db;
use think\Request;
/**
 *
 */
class User extends Controller
{
	//查询用户账号
	public function index(){
		$config = Db::table('think_user')->select();;
        $this->assign('config',$config);
		return $this->fetch();
	}
	//删除用户
	public function deluser(){
		//获取url
    	$request = Request::instance();
    	//拿到路径
    	$lead = $request->param();
    	//取到页面带过来的id
    	$lead_id = $lead['id'];
    	//删除数据
    	$config = Db::table('think_user')->where('id',$lead_id)->delete();
    	if($config == 1){
    		$this->success('删除用户成功','User/index');
    	}else{
    		$this->error('删除用户失败');
    	}
	}
	//查询用户留言
	public function lmsg(){
		$config = Db::table('think_lmsg')->select();;
        $this->assign('config',$config);
		return $this->fetch();
	}
	//删除用户留言
	public function dellmsg(){
		//获取url
    	$request = Request::instance();
    	//拿到路径
    	$lead = $request->param();
    	//取到页面带过来的id
    	$lead_id = $lead['id'];
    	//删除数据
    	$config = Db::table('think_lmsg')->where('id',$lead_id)->delete();
    	if($config == 1){
    		$this->success('删除用户留言成功','User/lmsg');
    	}else{
    		$this->error('删除用户留言失败');
    	}
	}
}






 ?>