<?php
namespace app\admin\controller;

use think\Controller;
use think\Db;
use think\Request;
/**
 *
 */
class Article extends Controller
{
	//查看文章列表
	public function index(){
		$config = Db::table('think_article')->select();;
        $this->assign('config',$config);
		return $this->fetch();
	}
	//删除文章
	public function delarticle(){
		//获取url
    	$request = Request::instance();
    	//拿到路径
    	$lead = $request->param();
    	//取到页面带过来的id
    	$lead_id = $lead['id'];
    	//删除数据
    	$config = Db::table('think_article')->where('id',$lead_id)->delete();
    	if($config == 1){
    		$this->success('删除文章成功','Article/index');
    	}else{
    		$this->error('删除文章失败');
    	}
	}
	//添加文章页面
	public function article(){
		return $this->fetch();
	}
	//处理添加文章提交的数据
	public function witharticle(){
		 // 获取表单上传文件 例如上传了001.jpg
	    $file = request()->file('photo');
	    // 移动到框架应用根目录/public/uploads/ 目录下
	    if($file){
	        $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
	        if($info){
	            // 成功上传后 获取上传信息
	            // 输出 jpg
	            // echo $info->getExtension();
	            // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
	            $photo = $info->getSaveName();
	            // 输出 42a79759f284b767dfcb2a0197904287.jpg
	            // echo $info->getFilename();
	        }else{
	            // 上传失败获取错误信息
	            echo $file->getError();
	        }
		}else{
			$photo = null;
		}
		$title = input('title');
		$remark = input('remark');
		$views = input('views');
		$content = input('content');
		$label = input('label');
		//写入数据到数据库中
		$data = [
			'title' => $title,
			'photo' => $photo,
			'remark' => $remark,
			'content' => $content,
			'views' => $views,
			'label' => $label,
			'create_time' => time()
		];
		//返回1就写入成功 0 就失败
		$log = Db::name('article')->insert($data);
		if($log == 1){
			//写入成功 跳转到返回写入页面
			$this->success('添加成功', 'Article/article');
		}else{
			$this->error("添加失败");
		}
	}
	//编辑文章
	public function editarticle(){
		//获取url
    	$request = Request::instance();
    	//拿到路径
    	$lead = $request->param();
    	//取到页面带过来的id
    	$lead_id = $lead['id'];
    	//返回数据数据
    	$config = Db::table('think_article')->where('id',$lead_id)->find();
    	$this->assign('config',$config);
		return $this->fetch();
	}
	//处理编辑好的文章，再提交到数据库
	public function eitindex(){
		//获取url
    	$request = Request::instance();
    	//拿到路径
    	$lead = $request->param();
    	//取到页面带过来的id
    	$lead_id = $lead['id'];
    	// 获取表单上传文件 例如上传了001.jpg
	    $file = request()->file('photo');
	    // 移动到框架应用根目录/public/uploads/ 目录下
	    if($file){
	        $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
	        if($info){
	            // 成功上传后 获取上传信息
	            // 输出 jpg
	            // echo $info->getExtension();
	            // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
	            $photo = $info->getSaveName();
	            // 输出 42a79759f284b767dfcb2a0197904287.jpg
	            // echo $info->getFilename();
	        }else{
	            // 上传失败获取错误信息
	            echo $file->getError();
	        }
		}else{
			$photo = null;
		}
		$title = input('title');
		$remark = input('remark');
		$views = input('views');
		$content = input('content');
		$label = input('label');
		//写入数据到数据库中
		$data = [
			'id' => $lead_id,
			'title' => $title,
			'photo' => $photo,
			'remark' => $remark,
			'content' => $content,
			'views' => $views,
			'label' => $label,
			'create_time' => time()
		];
		$log = Db::table('think_article')->where('id', $lead_id)->update($data);
		if($log == 1){
			//写入成功 跳转到返回写入页面
			$this->success('修改成功', 'Article/index');
		}else{
			$this->error("修改成功");
		}
	}
	//处理文章留言
	public function reviews(){
		$config = Db::table('think_article_reviews')->select();;
        $this->assign('config',$config);
		return $this->fetch();
	}
	//删除文章留言
	public function delreview(){
		//获取url
    	$request = Request::instance();
    	//拿到路径
    	$lead = $request->param();
    	//取到页面带过来的id
    	$lead_id = $lead['id'];
    	$config = Db::table('think_article_reviews')->where('id',$lead_id)->delete();
    	if($config == 1){
    		$this->success('删除用户文章留言成功','article/reviews');
    	}else{
    		$this->error('删除用户文章留言失败');
    	}
	}
}





?>